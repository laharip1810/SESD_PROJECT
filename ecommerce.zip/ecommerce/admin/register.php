<?php
session_start();
include '../includes/db.php';

$error_message = '';

if (isset($_POST['register'])) {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error_message = 'Please enter both email and password.';
    } else {
        try {
            $stmt = $conn->prepare("SELECT id FROM admins WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error_message = 'Email already registered!';
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $ins = $conn->prepare("INSERT INTO admins (email, password) VALUES (?, ?)");
                $ins->execute([$email, $hashed]);
                $_SESSION['admin_id'] = $conn->lastInsertId();
                header("Location: dashboard.php");
                exit();
            }
        } catch (Exception $e) {
            $error_message = 'Registration error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #1e90ff, #00b894);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .register-container {
            background: #fff;
            padding: 40px 35px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 420px;
            animation: fadeIn 0.7s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 26px;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .msg {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: 500;
        }

        .error {
            background: #ffeaea;
            color: #b30000;
            border: 1px solid #f5c2c7;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
            color: #444;
        }

        input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            outline: none;
            margin-bottom: 16px;
            transition: 0.3s;
            font-size: 15px;
        }

        input:focus {
            border-color: #00b894;
            box-shadow: 0 0 0 3px rgba(0, 184, 148, 0.2);
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #00b894, #1e90ff);
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        }

        .note {
            text-align: center;
            margin-top: 15px;
            font-size: 0.9em;
            color: #555;
        }

        .note a {
            color: #1e90ff;
            font-weight: 600;
            text-decoration: none;
        }

        .note a:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .register-container {
                padding: 30px 20px;
                margin: 0 15px;
            }
        }
    </style>
</head>
<body>

    <div class="register-container">
        <h2>Admin Registration</h2>

        <?php if ($error_message): ?>
            <div class="msg error"><?= htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" placeholder="Enter your email" required>

            <label for="password">Password</label>
            <input id="password" type="password" name="password" placeholder="Create a password" required>

            <button type="submit" name="register">Register</button>
        </form>

        <p class="note">Already an admin? <a href="login.php">Login here</a></p>
    </div>

</body>
</html>
