<?php
session_start();
include '../includes/db.php';

$error_message = '';

if (isset($_POST['login'])) {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error_message = 'Please enter both email and password.';
    } else {
        try {
            $stmt = $conn->prepare("SELECT id, email, password FROM admins WHERE email = ?");
            $stmt->execute([$email]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin && password_verify($password, $admin['password'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['id'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error_message = 'Invalid email or password.';
            }
        } catch (Exception $e) {
            $error_message = 'Login error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Admin Login</title>

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg1:#667eea;
            --bg2:#764ba2;
            --glass: rgba(255,255,255,0.12);
            --glass-strong: rgba(255,255,255,0.18);
            --accent:#ffe66d;
            --success-start:#43c67a;
            --success-end:#28a745;
        }

        *{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%}
        body{
            font-family:"Poppins",sans-serif;
            background: linear-gradient(135deg,var(--bg1),var(--bg2));
            display:flex;
            align-items:center;
            justify-content:center;
            padding:28px;
            color:#fff;
        }

        /* floating circles */
        .bg-circle{
            position:fixed;
            border-radius:50%;
            opacity:.18;
            filter: blur(18px);
            z-index:0;
            pointer-events:none;
        }
        .bg-circle.c1{ width:320px; height:320px; top:6%; left:6%; background:var(--bg1);}
        .bg-circle.c2{ width:360px; height:360px; bottom:6%; right:6%; background:var(--bg2);}

        .card {
            position:relative;
            z-index:2;
            width:100%;
            max-width:460px;
            background:var(--glass);
            border-radius:18px;
            padding:34px;
            box-shadow:0 18px 50px rgba(0,0,0,0.35);
            backdrop-filter: blur(12px) saturate(120%);
            border: 1px solid rgba(255,255,255,0.06);
            animation:enter .6s cubic-bezier(.2,.9,.2,1);
        }

        @keyframes enter {
            from { transform: translateY(18px); opacity:0 }
            to { transform: translateY(0); opacity:1 }
        }

        h2{
            font-size:1.6rem;
            margin-bottom:8px;
            text-align:center;
            letter-spacing:0.2px;
        }
        p.lead{
            text-align:center;
            color: rgba(255,255,255,0.85);
            margin-bottom:22px;
            font-size:0.95rem;
        }

        .msg {
            padding:12px 14px;
            border-radius:10px;
            margin-bottom:16px;
            font-weight:600;
            text-align:center;
        }
        .msg.error{
            background: rgba(220,53,69,0.13);
            border:1px solid rgba(220,53,69,0.25);
            color:#ffd7d9;
        }

        form{margin-top:6px}
        label{
            display:block;
            font-weight:600;
            font-size:0.9rem;
            margin-bottom:8px;
            color: rgba(255,255,255,0.9);
        }

        .field {
            position:relative;
            margin-bottom:14px;
        }

        input[type="email"],
        input[type="password"]{
            width:100%;
            padding:12px 14px;
            border-radius:10px;
            border: none;
            background: rgba(255,255,255,0.06);
            color: #fff;
            font-size:1rem;
            outline: none;
            transition: box-shadow .18s, background .18s, transform .12s;
            -webkit-appearance: none;
        }
        input::placeholder{ color: rgba(255,255,255,0.6) }

        input:focus{
            background: var(--glass-strong);
            box-shadow: 0 6px 20px rgba(102,126,234,0.12);
            transform: translateY(-1px);
        }

        /* show/hide password toggle */
        .password-wrapper{
            display:flex;
            align-items:center;
            gap:8px;
        }
        .toggle-visibility{
            position:absolute;
            right:10px;
            top:50%;
            transform:translateY(-50%);
            background:transparent;
            border:none;
            color: rgba(255,255,255,0.85);
            cursor:pointer;
            font-size:0.95rem;
            padding:6px;
            border-radius:6px;
        }
        .toggle-visibility:hover{ background: rgba(255,255,255,0.04) }

        button.btn{
            width:100%;
            padding:12px;
            border-radius:10px;
            border:none;
            cursor:pointer;
            font-weight:700;
            font-size:1rem;
            color:#fff;
            background: linear-gradient(135deg,var(--success-start),var(--success-end));
            box-shadow: 0 10px 30px rgba(40,167,69,0.14);
            transition: transform .12s, box-shadow .12s;
        }
        button.btn:hover{ transform: translateY(-3px); box-shadow: 0 18px 40px rgba(40,167,69,0.2) }

        .note{
            margin-top:14px;
            text-align:center;
            font-size:0.92rem;
            color: rgba(255,255,255,0.9);
        }
        .note a{ color: var(--accent); font-weight:700; text-decoration:none }
        .note a:hover{text-decoration:underline}

        @media (max-width:480px){
            .card{ padding:22px }
            h2{ font-size:1.3rem }
        }
    </style>
</head>
<body>
    <div class="bg-circle c1"></div>
    <div class="bg-circle c2"></div>

    <div class="card" role="main" aria-labelledby="admin-login-title">
        <h2 id="admin-login-title">🔐 Admin Login</h2>
        <p class="lead">Sign in to access the dashboard</p>

        <?php if ($error_message): ?>
            <div class="msg error"><?= htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="off" novalidate>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" placeholder="admin@example.com">
            </div>

            <div class="field" style="margin-bottom:18px;">
                <label for="password">Password</label>
                <div class="password-wrapper" style="position:relative;">
                    <input id="password" type="password" name="password" required placeholder="Enter your password" aria-describedby="pw-toggle">
                    <button type="button" class="toggle-visibility" id="pw-toggle" aria-label="Show password">Show</button>
                </div>
            </div>

            <button type="submit" name="login" class="btn">Login</button>
        </form>

        <p class="note">If no admin exists, <a href="register.php">create one</a>.</p>
    </div>

    <script>
        // Show/Hide password (front-end only)
        (function(){
            const pwInput = document.getElementById('password');
            const toggle = document.getElementById('pw-toggle');

            toggle.addEventListener('click', function(){
                if (pwInput.type === 'password') {
                    pwInput.type = 'text';
                    toggle.textContent = 'Hide';
                    toggle.setAttribute('aria-pressed', 'true');
                } else {
                    pwInput.type = 'password';
                    toggle.textContent = 'Show';
                    toggle.setAttribute('aria-pressed', 'false');
                }
                pwInput.focus();
            });
        })();
    </script>
</body>
</html>
